#!/bin/bash
# SmartSortingBin Kiosk 部署脚本
# 用法: sudo bash setup-kiosk.sh

set -e

echo "===== SmartSortingBin Kiosk 部署 ====="

# 1. 强制使用 X11 代替 Wayland（解决触摸屏多指手势问题）
echo "[1/3] 切换到 X11 会话..."
GDM_CONF="/etc/gdm3/custom.conf"
if [ -f "$GDM_CONF" ]; then
  # 取消注释 WaylandEnable=false，或添加
  if grep -q "^#WaylandEnable=false" "$GDM_CONF"; then
    sed -i 's/^#WaylandEnable=false/WaylandEnable=false/' "$GDM_CONF"
  elif ! grep -q "^WaylandEnable=false" "$GDM_CONF"; then
    sed -i '/^\[daemon\]/a WaylandEnable=false' "$GDM_CONF"
  fi
  echo "  已设置 WaylandEnable=false"
else
  echo "  警告: 未找到 $GDM_CONF，请手动禁用 Wayland"
fi

# 2. 禁用自动锁屏和屏保
echo "[2/3] 禁用锁屏和屏保..."
sudo -u $SUDO_USER dconf write /org/gnome/desktop/screensaver/lock-enabled false 2>/dev/null || true
sudo -u $SUDO_USER dconf write /org/gnome/desktop/session/idle-delay "uint32 0" 2>/dev/null || true
sudo -u $SUDO_USER dconf write /org/gnome/settings-daemon/plugins/power/sleep-inactive-ac-type "'nothing'" 2>/dev/null || true
sudo -u $SUDO_USER dconf write /org/gnome/settings-daemon/plugins/power/idle-dim false 2>/dev/null || true
echo "  已禁用锁屏和屏保"

# 3. 禁用自动更新弹窗
echo "[3/3] 禁用自动更新提示..."
sudo -u $SUDO_USER dconf write /org/gnome/software/download-updates false 2>/dev/null || true
sudo -u $SUDO_USER dconf write /org/gnome/software/allow-updates false 2>/dev/null || true
echo "  已禁用自动更新"

echo ""
echo "===== 部署完成 ====="
echo "请重启设备使 X11 切换生效: sudo reboot"
echo "重启后三指手势将不再触发桌面操作"
