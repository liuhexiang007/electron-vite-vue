<template>
  <router-view />
  <AdminExit />
</template>

<script setup lang="ts">
import AdminExit from '@/components/AdminExit.vue'
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html, body, #app {
  width: 100%;
  height: 100%;
  overflow: hidden;
}
</style>
